import React, { useEffect, useState } from "react";
import "./index.css"
import "./App.css"
import News from "./News";

const App=() =>{
  let [articles, setArticles]=useState([]);
  let [category,setCategory]= useState("india");
  let [date,setDate]= useState("2023-12-7");


  useEffect( ()=>{
    fetch(`https://newsapi.org/v2/everything?q=${category}&from=${date}&apiKey=63ebfb908224464c82ab33ca14e2da98`)
    .then((response) => response.json())
    .then((news)=>{
      setArticles(news.articles);
      console.log(news.articles);
    })
    .catch((err)=>{
      console.log(err);
    })      
  },[category,date])


  return (
    <>
    <header className="header">
    <h1>News Tak</h1>
    <input type="text" onChange={(event)=>{
      if(event.target.value !== ""){
        setCategory(event.target.value);
      }
      else{
        setCategory("india");
      }
    }} placeholder="Search News"/>
    <input type="date" onChange={(event)=>{
      if(event.target.value!==""){
        setDate(event.target.value);
      }
      else{
        setDate(2023-12-7);
      }
    }}/>

    </header>
    <section className="news_Articles">
    {
      articles.length!==0 ?
      articles.map((article)=>{
        return(
          <News article={article}/>
        );
      }):
      <h1>No News Found For Searched Text By YOU!</h1>
    }

    </section>

    </>
  );
}

export default App;
